﻿namespace IOT.Models;

public class Employee
{
	public int Id { get; set; }
	public required string Name { get; set; }
	public required string Surname { get; set; }
	public required string Card { get; set; }
	
	public ICollection<EmployeeEntrance> Entrances { get; set; } = [];
}