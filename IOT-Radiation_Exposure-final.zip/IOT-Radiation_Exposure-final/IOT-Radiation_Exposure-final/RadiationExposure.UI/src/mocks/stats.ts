export const stats = [
  {
    name: "registered workers",
    value: 13,
  },
  {
    name: "rooms with radiation exposure",
    value: 4,
  },
  {
    name: "entrances today",
    value: 25,
  },
  {
    name: "workers above radiation limit",
    value: 2,
  }
];